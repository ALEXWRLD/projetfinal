const knex = require("knex")({
    client: "sqlite3",
    connection: {
        filename:"./database/database.sqlite"
    },

    useNullAsDefault: false
})

async function getEtudiants() {
    return await knex("etudiants");
}

function ajouterEtudiant(etudiant) {
    return knex("etudiants").insert(etudiant);
}

module.exports = {
    getEtudiants,
    ajouterEtudiant
}