const express = require("express");
const requeteKnex = require("./database/requeteKnex");
const cors = require("cors");
const PORT = process.env.PORT || 2000;
const app = express();
var path = require('path');


app.use(cors());
app.use(express.urlencoded({extended: false}))

app.post("/login", async (request, reponse) => {
    var username = request.body.nom_utilisateur;
    var password = request.body.mot_de_passe;
    if (username && password) {
		connection.query('SELECT * FROM admin WHERE nom_utilisateur = ? AND password = ?', [username, password], function(error, results, fields) {
			if (results.length > 0) {
				request.session.loggedin = true;
				request.session.username = username;
				response.send('Bon login !');
			} else {
				response.send('Mauvais login !');
			}			
			response.end();
		});
	} else {
		response.send('Entrez le nom d utilisateur et le mot de passe!');
		response.end();
	}
});
    

app.listen(PORT, () =>{
    console.log(`Mon application roule sur le port ${PORT}`);
})