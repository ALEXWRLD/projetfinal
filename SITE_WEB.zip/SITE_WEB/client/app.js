const exp = require("constants");
const express = require("express");
const path = require("path")
const PORT = process.env.PORT || 5000;

const app = express();

app.use(express.static(path.join(__dirname, "public")));

app.get("/login", (req, reponse) =>{
    reponse.sendFile(path.join(__dirname,"/public/login.html"));
})

app.get("/Accueil", (req, reponse) =>{
    reponse.sendFile(__dirname + "/public/Accueil.html");
})

app.listen(PORT, () => {
    console.log(`Mon application frontale roule sur le port ${PORT}`);
})