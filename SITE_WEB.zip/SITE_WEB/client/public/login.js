function login(event) {
    event.preventDefault();
    let formData = new URLSearchParams(new FormData(event.target));

    fetch("http://localhost:2000/login", { method: "POST", body : formData})
    .then(reponse => {
        return reponse.json();
    })
    .then(reponseJson =>{
        if (reponseJson.success) {
            alert("Vous vous êtes bien connecté");
            window.location.href = "http://localhost:5000";
        }
    })
    .catch(err =>{
        alert("Oupps, quelque chose ne marche pas!");
    })
}